import os
from fastapi.testclient import TestClient
from app.main import app
from app.db import init_db
init_db()
client = TestClient(app)

def test_health():
    r = client.get('/health/')
    assert r.status_code == 200
    assert r.json() == {'status': 'ok'}

def test_upload_and_get():
    files = {'file': ('hello.txt', b'hello world')}
    r = client.post('/api/upload?author=alice&title=hello', files=files)
    assert r.status_code == 200
    data = r.json()
    assert data['title'] == 'hello'
    doc_id = data['id']
    g = client.get(f'/api/documents/{doc_id}')
    assert g.status_code == 200
    assert g.json()['title'] == 'hello'
