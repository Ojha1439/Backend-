from fastapi import FastAPI
from .routers import docs, health

app = FastAPI(title="CollabDoc Backend Prototype")

app.include_router(health.router, prefix="/health")
app.include_router(docs.router, prefix="/api")
