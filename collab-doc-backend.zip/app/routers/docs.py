from fastapi import APIRouter, UploadFile, File, HTTPException, Query
from fastapi.responses import FileResponse
from .. import crud, schemas, models, storage
from ..db import SessionLocal, init_db
from sqlalchemy.orm import Session
import shutil, os

router = APIRouter()

init_db()  # ensure DB/tables exist

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.post('/upload', response_model=schemas.DocumentOut)
async def upload(file: UploadFile = File(...), title: str = Query(None), author: str = Query(...), tags: str = Query(None)):
    db = next(get_db())
    contents = await file.read()
    # basic validations
    if not contents:
        raise HTTPException(400, 'Empty file')
    # store file
    doc = crud.create_or_update_document(db, title=title or file.filename, author=author, filename=file.filename, content=contents, tags=tags)
    return schemas.DocumentOut.from_orm(doc)

@router.get('/documents/{doc_id}', response_model=schemas.DocumentOut)
def get_document(doc_id: int):
    db = next(get_db())
    doc = crud.get_document(db, doc_id)
    if not doc:
        raise HTTPException(404, 'Document not found')
    return schemas.DocumentOut.from_orm(doc)

@router.get('/documents/{doc_id}/download')
def download(doc_id: int, version: int = Query(None)):
    db = next(get_db())
    v = crud.get_version(db, doc_id, version)
    if not v:
        raise HTTPException(404, 'version not found')
    return FileResponse(v.file_path, filename=os.path.basename(v.file_path))

@router.post('/documents/{doc_id}/share')
def share(doc_id: int, user: str = Query(...), permission: str = Query(...)):
    db = next(get_db())
    try:
        crud.share_with(db, doc_id, user, permission)
    except Exception as e:
        raise HTTPException(400, str(e))
    return {"status": "ok"}

@router.get('/search')
def search(q: str = Query(None), tags: str = Query(None), author: str = Query(None), min_size: int = Query(None), max_size: int = Query(None), from_date: str = Query(None), to_date: str = Query(None)):
    db = next(get_db())
    results = crud.search(db, q=q, tags=tags, author=author, min_size=min_size, max_size=max_size, from_date=from_date, to_date=to_date)
    return [schemas.DocumentOut.from_orm(r) for r in results]
