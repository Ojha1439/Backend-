from pydantic import BaseModel
from typing import List, Optional
import datetime

class DocumentVersionOut(BaseModel):
    id: int
    version_number: int
    file_path: str
    uploaded_at: datetime.datetime
    size: int
    changelog: str

    class Config:
        orm_mode = True

class DocumentOut(BaseModel):
    id: int
    title: str
    owner: str
    created_at: datetime.datetime
    tags: str
    size: int
    versions: List[DocumentVersionOut] = []

    class Config:
        orm_mode = True
