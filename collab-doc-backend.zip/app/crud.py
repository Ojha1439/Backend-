import os
from . import models, storage
import datetime
from sqlalchemy.orm import Session
from sqlalchemy import desc

STORAGE_DIR = './data/files'
os.makedirs(STORAGE_DIR, exist_ok=True)

def create_or_update_document(db: Session, title: str, author: str, filename: str, content: bytes, tags: str = None):
    # Check if document with same title+owner exists (simple dedupe)
    doc = db.query(models.Document).filter(models.Document.title==title, models.Document.owner==author).first()
    size = len(content)
    if not doc:
        doc = models.Document(title=title, owner=author, tags=tags or '', size=size)
        db.add(doc)
        db.commit()
        db.refresh(doc)
        version_number = 1
    else:
        # new version
        last = db.query(models.DocumentVersion).filter(models.DocumentVersion.document_id==doc.id).order_by(desc(models.DocumentVersion.version_number)).first()
        version_number = (last.version_number + 1) if last else 1
        doc.size = size
        doc.tags = tags or doc.tags
        db.add(doc)
        db.commit()
        db.refresh(doc)

    # store file to disk
    safe_name = f"doc_{doc.id}_v{version_number}_{filename}"
    path = os.path.join(STORAGE_DIR, safe_name)
    storage.save_file(path, content)

    ver = models.DocumentVersion(document_id=doc.id, version_number=version_number, file_path=path, uploaded_at=datetime.datetime.utcnow(), size=size)
    db.add(ver)
    db.commit()
    db.refresh(ver)
    return doc

def get_document(db: Session, doc_id: int):
    return db.query(models.Document).filter(models.Document.id==doc_id).first()

def get_version(db: Session, doc_id: int, version: int = None):
    q = db.query(models.DocumentVersion).filter(models.DocumentVersion.document_id==doc_id)
    if version:
        q = q.filter(models.DocumentVersion.version_number==version)
    else:
        q = q.order_by(desc(models.DocumentVersion.version_number)).limit(1)
    return q.first()

def share_with(db: Session, doc_id: int, user: str, permission: str):
    # validate
    if permission not in ('read','edit','admin'):
        raise ValueError('permission must be one of read/edit/admin')
    s = models.DocumentShare(document_id=doc_id, user=user, permission=permission)
    db.add(s)
    db.commit()
    db.refresh(s)
    return s

def search(db: Session, q: str=None, tags: str=None, author: str=None, min_size: int=None, max_size: int=None, from_date: str=None, to_date: str=None):
    qry = db.query(models.Document)
    if q:
        qry = qry.filter(models.Document.title.ilike(f"%{q}%"))
    if tags:
        # simple contains search
        for t in tags.split(','):
            qry = qry.filter(models.Document.tags.ilike(f"%{t.strip()}%"))
    if author:
        qry = qry.filter(models.Document.owner==author)
    if min_size:
        qry = qry.filter(models.Document.size >= min_size)
    if max_size:
        qry = qry.filter(models.Document.size <= max_size)
    # date filters omitted for brevity
    return qry.all()
