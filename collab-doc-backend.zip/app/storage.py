def save_file(path: str, data: bytes):
    with open(path, 'wb') as f:
        f.write(data)
