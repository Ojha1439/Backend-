from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, Enum, Table
from sqlalchemy.orm import relationship, declarative_base
import datetime, enum

Base = declarative_base()

class PermissionEnum(str, enum.Enum):
    READ = 'read'
    EDIT = 'edit'
    ADMIN = 'admin'

class User(Base):
    __tablename__ = 'users'
    id = Column(Integer, primary_key=True, index=True)
    username = Column(String, unique=True, index=True)

class Document(Base):
    __tablename__ = 'documents'
    id = Column(Integer, primary_key=True, index=True)
    title = Column(String, index=True)
    owner = Column(String, index=True)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    # simplify tags as comma separated list for prototype
    tags = Column(String, default='')
    size = Column(Integer, default=0)

    versions = relationship('DocumentVersion', back_populates='document', cascade='all, delete-orphan')
    shares = relationship('DocumentShare', back_populates='document', cascade='all, delete-orphan')

class DocumentVersion(Base):
    __tablename__ = 'document_versions'
    id = Column(Integer, primary_key=True, index=True)
    document_id = Column(Integer, ForeignKey('documents.id'))
    version_number = Column(Integer, default=1)
    file_path = Column(String)
    uploaded_at = Column(DateTime, default=datetime.datetime.utcnow)
    size = Column(Integer, default=0)
    changelog = Column(String, default='')

    document = relationship('Document', back_populates='versions')

class DocumentShare(Base):
    __tablename__ = 'document_shares'
    id = Column(Integer, primary_key=True, index=True)
    document_id = Column(Integer, ForeignKey('documents.id'))
    user = Column(String, index=True)
    permission = Column(Enum(PermissionEnum))

    document = relationship('Document', back_populates='shares')
